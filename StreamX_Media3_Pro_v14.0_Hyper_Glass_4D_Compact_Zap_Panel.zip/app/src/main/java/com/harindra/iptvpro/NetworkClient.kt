package com.harindra.iptvpro

import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.net.InetAddress
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Upgrade 9 & v14.0 Hyper-Glass: Persistent Connection Pool, TCP Keep-Alive, Bounded In-Memory DNS Cache,
 * Session CookieJar, and Custom Stream Header Registry.
 * Preserves isolated metadataDispatcher, apiDispatcher, and streamDispatcher so background
 * requests never starve live HLS/DASH segment fetches on 512 MB RAM Android TVs.
 */
object NetworkClient {
    const val DEFAULT_USER_AGENT = "StreamX-Media3Pro/14.0-HyperGlass (AndroidTV)"
    private const val DNS_TTL_MS = 30L * 60L * 1000L // 30-minute TTL
    private const val MAX_DNS_ENTRIES = 64
    private const val MAX_HEADER_ENTRIES = 512
    private const val MAX_COOKIE_HOSTS = 64

    private data class DnsEntry(
        val addresses: List<InetAddress>,
        val timestampMs: Long
    )

    private val dnsCache = ConcurrentHashMap<String, DnsEntry>(64)
    private val customStreamHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val hostStreamHeaders = ConcurrentHashMap<String, Map<String, String>>(32)
    private val sessionCookiesByHost = ConcurrentHashMap<String, List<Cookie>>(32)

    private val ALLOWED_CUSTOM_HEADERS = setOf(
        "user-agent",
        "referer",
        "origin",
        "authorization",
        "cookie",
        "x-forwarded-for"
    )

    /**
     * Bounded thread-safe in-memory DNS cache (max 64 hosts, 30-min TTL)
     * so channel switches on the same or previously visited IPTV host require 0ms DNS lookup.
     */
    val quantumDns: Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val key = hostname.lowercase()
            val now = System.currentTimeMillis()
            val cached = dnsCache[key]
            if (cached != null && (now - cached.timestampMs) < DNS_TTL_MS && cached.addresses.isNotEmpty()) {
                return cached.addresses
            }
            val resolved = Dns.SYSTEM.lookup(hostname)
            if (resolved.isNotEmpty()) {
                if (dnsCache.size >= MAX_DNS_ENTRIES) {
                    val oldestKey = dnsCache.entries.minByOrNull { it.value.timestampMs }?.key
                    if (oldestKey != null) dnsCache.remove(oldestKey)
                }
                dnsCache[key] = DnsEntry(resolved, now)
            }
            return resolved
        }
    }

    /**
     * Lightweight in-memory CookieJar so IPTV session cookies set on manifest redirects
     * are preserved between StreamPreFetcher and ExoPlayer's OkHttpDataSource.
     */
    val sessionCookieJar: CookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            if (cookies.isEmpty()) return
            val host = url.host.lowercase()
            if (sessionCookiesByHost.size >= MAX_COOKIE_HOSTS && !sessionCookiesByHost.containsKey(host)) {
                val firstKey = sessionCookiesByHost.keys.firstOrNull()
                if (firstKey != null) sessionCookiesByHost.remove(firstKey)
            }
            val now = System.currentTimeMillis()
            val existing = sessionCookiesByHost[host].orEmpty().filter { it.expiresAt > now }
            val merged = HashMap<String, Cookie>(existing.size + cookies.size)
            for (c in existing) merged[c.name] = c
            for (c in cookies) merged[c.name] = c
            sessionCookiesByHost[host] = merged.values.toList()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val host = url.host.lowercase()
            val list = sessionCookiesByHost[host] ?: return emptyList()
            val now = System.currentTimeMillis()
            return list.filter { it.expiresAt > now && it.matches(url) }
        }
    }

    /**
     * Parses pipe-syntax IPTV URLs (e.g. "https://host/live.m3u8|User-Agent=Custom&Referer=https://...")
     * and optional #EXTVLCOPT/#KODIPROP header maps, registers them for both preload and playback,
     * and returns the clean stream URL.
     */
    fun extractCleanUrlAndRegisterHeaders(
        rawUrl: String,
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        val trimmed = rawUrl.trim()
        val pipeIdx = trimmed.indexOf('|')
        val cleanUrl = if (pipeIdx > 0) trimmed.substring(0, pipeIdx).trim() else trimmed
        val merged = LinkedHashMap<String, String>()

        for ((k, v) in extraHeaders) {
            val cleanKey = k.trim()
            val cleanVal = v.trim()
            if (cleanKey.lowercase() in ALLOWED_CUSTOM_HEADERS && cleanVal.isNotEmpty()) {
                merged[cleanKey] = cleanVal
            }
        }

        if (pipeIdx > 0 && pipeIdx < trimmed.lastIndex) {
            val headerPart = trimmed.substring(pipeIdx + 1)
            for (pair in headerPart.split('&')) {
                val eq = pair.indexOf('=')
                if (eq > 0) {
                    val rawKey = pair.substring(0, eq).trim()
                    val rawVal = runCatching {
                        URLDecoder.decode(pair.substring(eq + 1).trim(), "UTF-8")
                    }.getOrElse { pair.substring(eq + 1).trim() }
                    if (rawKey.lowercase() in ALLOWED_CUSTOM_HEADERS && rawVal.isNotEmpty()) {
                        merged[rawKey] = rawVal
                    }
                }
            }
        }

        if (merged.isNotEmpty() && cleanUrl.isNotEmpty()) {
            registerStreamHeaders(cleanUrl, merged)
        }
        return cleanUrl
    }

    fun registerStreamHeaders(streamUrl: String, headers: Map<String, String>) {
        if (streamUrl.isBlank() || headers.isEmpty()) return
        if (customStreamHeaders.size >= MAX_HEADER_ENTRIES) {
            val firstKey = customStreamHeaders.keys.firstOrNull()
            if (firstKey != null) customStreamHeaders.remove(firstKey)
        }
        customStreamHeaders[streamUrl] = headers
        val host = streamUrl.toHttpUrlOrNull()?.host?.lowercase()
        if (!host.isNullOrBlank()) {
            hostStreamHeaders[host] = headers
        }
    }

    fun headersForUrl(url: String): Map<String, String> {
        customStreamHeaders[url]?.let { return it }
        val baseNoQuery = url.substringBefore('?')
        customStreamHeaders.entries.firstOrNull { it.key.substringBefore('?') == baseNoQuery }?.value?.let { return it }
        val host = url.toHttpUrlOrNull()?.host?.lowercase()
        if (!host.isNullOrBlank()) {
            hostStreamHeaders[host]?.let { return it }
        }
        return emptyMap()
    }

    /**
     * Redacts passwords, tokens, and Xtream /live/<user>/<pass>/ path segments so sensitive
     * credentials are never written to Logcat or exposed in error strings.
     */
    fun redactSensitiveUrl(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var masked = raw.replace(
            Regex("(?i)(password|pass|token|auth|key|wmsAuthSign|signature)=([^&\\s]+)"),
            "$1=****"
        )
        masked = masked.replace(
            Regex("(?i)(/live/[^/]+/)([^/]+)(/)"),
            "$1****$3"
        )
        return masked
    }

    private val streamHeaderInterceptor = Interceptor { chain ->
        val original = chain.request()
        val urlStr = original.url.toString()
        val custom = headersForUrl(urlStr)
        val builder = original.newBuilder()
        if (original.header("User-Agent").isNullOrBlank()) {
            builder.header("User-Agent", DEFAULT_USER_AGENT)
        }
        for ((k, v) in custom) {
            if (original.header(k).isNullOrBlank() || k.equals("User-Agent", ignoreCase = true)) {
                builder.header(k, v)
            }
        }
        chain.proceed(builder.build())
    }

    fun prewarmHostDns(streamUrl: String?) {
        if (streamUrl.isNullOrBlank()) return
        runCatching {
            val host = streamUrl.toHttpUrlOrNull()?.host ?: return
            quantumDns.lookup(host)
        }
    }

    private fun dispatcher(max: Int, perHost: Int) = Dispatcher().apply {
        maxRequests = max
        maxRequestsPerHost = perHost
    }

    private fun pool(maxIdle: Int) = ConnectionPool(maxIdle, 5, TimeUnit.MINUTES)

    private val metadataDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val apiDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val streamDispatcher by lazy { dispatcher(max = 12, perHost = 6) }

    private val metadataPool by lazy { pool(maxIdle = 4) }
    private val apiPool by lazy { pool(maxIdle = 4) }
    private val streamPool by lazy { pool(maxIdle = 8) }

    /** Short, bounded calls for connection checks, pre-fetch warmup and lightweight metadata. */
    val fastMetaClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(metadataPool)
            .dispatcher(metadataDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Longer timeouts for M3U, Xtream and XMLTV responses. */
    val apiClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(apiPool)
            .dispatcher(apiDispatcher)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Dedicated live-stream dispatcher with 0ms cached DNS, session CookieJar, custom headers & 5-min keep-alive pool. */
    val streamClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .addInterceptor(streamHeaderInterceptor)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(streamPool)
            .dispatcher(streamDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            // 20s is still bounded while tolerating brief Wi-Fi jitter on live segments.
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}
